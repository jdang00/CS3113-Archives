/************************************
Name:           <YOUR NAME>
Problem Set:    Problem Set 1
Due Date:       <Due Date>
************************************/


public class ProblemSet1 {
	
	public static void main(String[] args) {
		
		String studentName = "INSERT YOUR NAME HERE";  
		
		/***************************************************************
		 * DO NOT CHANGE ANYTHING ELSE BELOW THIS LINE IN THIS METHOD
		 ***************************************************************/
		
		/*
		 * Note:  If you use an IDE, you can set the command-line arguments for testing purposes through
		 * the IDE's runtime configuration. Simply ask if you do not know how to do this.
		 */
		
		if ( args.length < 2) {
			System.out.println("Invalid syntax.  Usage:  java ProblemSet1 filename colnumber");
			return;
		}
		
		try {
			
			ProblemSet1 ps = new ProblemSet1();
			
			String filename = args[0];
			int col = Integer.parseInt(args[1]);
			
			System.out.printf("[ Input arguments ] %n");
			System.out.printf("   Student Name ..................... %s %n", studentName);
			System.out.printf("   Input file ....................... %s %n", filename);
			System.out.printf("   Input column ..................... %d %n", col);
			
			System.out.println();
			
			
			/***************************************************************
			 * Calling step 1
			 ***************************************************************/
			
			System.out.println("[ Results ]");
			System.out.print("Step 1) Reading the file .......................... ");
			double[][] X = ps.readFile(filename);
			System.out.println("[done]");
			 
			int numColumns = (X != null && X[0] != null ? X[0].length : 0);
			System.out.printf("      Total number of records ..................... %d %n", (X != null ? X.length : 0) ) ;
			System.out.printf("      Total number of columns ..................... %d %n", numColumns ) ;
			System.out.println();
			
			
			/***************************************************************
			 * Calling step 2
			 ***************************************************************/
			System.out.printf("Step 2) Obtaining average for column [%d] .......... ", col);
			double average = ps.getAverage(ps.getColumnVector(X, col));
			System.out.println("[done]");
			System.out.printf("      Requested column [%d] average ................ %.3f %n", col, average  ) ;
			System.out.println();
			for ( int i = 0; i < numColumns; i++ ) {
				average = ps.getAverage(ps.getColumnVector(X, i));
				System.out.printf("      Column [%d] average .......................... %.3f %n", i, average  ) ;	
			}
			System.out.println();
			
			
			
			/***************************************************************
			 * Calling step 3
			 ***************************************************************/
			
			System.out.printf("Step 3) Obtaining output for run1(x%d) ............. ", col);
			double run1Output = ps.run1(ps.getColumnVector(X, col));
			System.out.println("[done]");
			
			System.out.printf("      Output from run1(x%d) ........................ %.3f %n", col, run1Output  ) ;
			System.out.println();
			
			
			
			
			/***************************************************************
			 * Calling step 4
			 ***************************************************************/
			System.out.printf("Step 4) Obtaining output for run2(x%d) ............. ", col);
			double run2Output = ps.run2(X);
			System.out.println("[done]");
			
			System.out.printf("      Output from run2(x%d) ........................ %.3f %n", col, run2Output  ) ;

			
			System.out.println();
			
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
	}
	
	
	/***********************************************************************
	 * CODE TO IMPLEMENT:  Implement the following methods
	 ***********************************************************************/
	
	
	/*
	 * Return a matrix for the file provided as a command-line argument
	 */
	public double[][] readFile(String filename) {
		return null;
	}
	
	/*
	 * Return an array that represents the k-th column vector
	 */
	public double[] getColumnVector(double[][] data, int k) {
		
		return null;
	}
	
	/*
	 * Return the average for the vector provided
	 */
	public double getAverage(double[] x) {
		return 0;
	}
	
	
	/*
	 * Return the calculation as indicated in the problem set
	 */
	public double run1(double[] x) {
		return 0;
	}
	
	/*
	 * Return the calculation as indicated in the problem set
	 */
	
	public double run2(double[][] x) {
		return 0;
	}
	
	

}
